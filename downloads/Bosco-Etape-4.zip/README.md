# Bosco — Étape 4 : cerveau et moteur décisionnel

Version 4.0.0 — 26 juillet 2026

Cette livraison ne crée ni ne modifie aucune illustration. Elle pilote exclusivement les références verrouillées des étapes 1 à 3.

## Rôle des dix fichiers

1. `bosco-brain.json` — orchestration générale du raisonnement, priorités, espace combinatoire des scénarios, confiance, anti-répétition et contraintes de performance.
2. `bosco-rules.json` — règles de sécurité, décisions, conseils secondaires et explication humaine de chaque règle. Les règles sont évaluées par priorité décroissante.
3. `bosco-dialogues.json` — bibliothèque de 432 phrases françaises, classées par situation, avec règles de ton, personnalisation et sélection anti-répétitive.
4. `bosco-emotions.json` — dix émotions, leur pose, leur expression, leur animation, leur ton et leur affinité avec les décisions.
5. `bosco-user-profile.json` — schéma du profil demandé au premier lancement, valeurs autorisées, validation et règles d’utilisation du prénom.
6. `bosco-navigation-score.json` — calcul du score sur 10, poids des sept dimensions, plafonds de sécurité, bandes de décision et format d’explication.
7. `bosco-weather-engine.json` — unités canoniques, champs météo et marins, seuils de catégorisation, valeurs dérivées et politique des données manquantes ou anciennes.
8. `bosco-assets-map.json` — correspondance entre les six décisions, les douze poses, les dix émotions, les animations et les effets visuels déjà existants.
9. `bosco-events.json` — réactions de 1 à 3 secondes aux arrivées de données, changements de spot, GPS, alertes et pertes ou retours de connexion.
10. `bosco-memory.json` — faits locaux autorisés, clés de stockage et interdiction explicite d’inventer un souvenir ou de transformer une prévision en sortie effectuée.

## Ordre d’exécution

1. Normaliser les unités.
2. Vérifier la fraîcheur et la cohérence des données.
3. Dériver les scénarios : facteur de rafale, mer croisée, relation du vent au rivage et tendances.
4. Appliquer les limites de sécurité.
5. Calculer les sept dimensions du score.
6. Retenir la décision finale et sa confiance.
7. Sélectionner l’émotion, la pose, l’asset et les effets.
8. Choisir une phrase non récemment utilisée.
9. Produire le score et ses raisons explicites.

## Garanties

- La sécurité représente 42 % du score et peut imposer un plafond absolu.
- Une alerte orageuse, un vent violent, une mer très forte, un brouillard dense ou l’absence de données peut forcer la décision.
- Le niveau utilisateur n’augmente jamais une limite de sécurité.
- Les phrases identiques sont interdites par validation automatique.
- L’application peut calculer hors ligne avec des données en cache, mais affiche une confiance réduite et l’âge du relevé.
- La mémoire n’utilise que les informations réellement enregistrées sur l’appareil.
